<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/ConfiguracionSistema.php';
require_once __DIR__ . '/../models/LogActividad.php';
require_once __DIR__ . '/../models/BackupRegistro.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

class AdminGestionTecnicaController {
    public static function index() {
        require_role('admin');

        $configuraciones = ConfiguracionSistema::getAll();

        $log_filters = [
            'accion' => input('log_accion', ''),
            'usuario_id' => input('log_usuario_id', ''),
            'fecha_desde' => input('log_fecha_desde', ''),
            'fecha_hasta' => input('log_fecha_hasta', ''),
            'busqueda' => input('log_busqueda', '')
        ];
        $log_page = max(1, intval(input('log_page', 1)));
        $log_data = LogActividad::getAll($log_filters, $log_page, 15);
        $acciones_disponibles = LogActividad::getAcciones();

        $backups = BackupRegistro::getAll();

        return [
            'configuraciones' => $configuraciones,
            'log_filters' => $log_filters,
            'log_data' => $log_data,
            'acciones_disponibles' => $acciones_disponibles,
            'backups' => $backups,
            'actividad_hoy' => LogActividad::countHoy()
        ];
    }

    public static function actualizarConfiguracion() {
        require_role('admin');
        if (!is_post()) {
            redirect('index.php?page=admin/configuracion');
            return;
        }
        if (!verify_csrf_token(input('csrf_token', ''))) {
            flash('errors', ['Token de seguridad inválido. Recargue la página e intente nuevamente.']);
            redirect('index.php?page=admin/configuracion');
            return;
        }

        $configuraciones = ConfiguracionSistema::getAll();
        $errors = [];
        $actualizados = 0;

        foreach ($configuraciones as $conf) {
            $clave = $conf['clave'];
            $tipo = $conf['tipo'];

            if ($tipo === 'booleano') {
                // Un checkbox no marcado no viaja en el POST: su ausencia significa "0".
                $valor = isset($_POST["conf_$clave"]) ? '1' : '0';
            } else {
                if (!array_key_exists("conf_$clave", $_POST)) {
                    continue; // este campo no se envió en este submit
                }
                $valor = trim((string) input("conf_$clave", ''));

                if ($tipo === 'numero' && $valor !== '' && !is_numeric($valor)) {
                    $errors[] = "El valor de \"$clave\" debe ser numérico";
                    continue;
                }
            }

            if ($valor !== (string) $conf['valor']) {
                ConfiguracionSistema::actualizarValor($clave, $valor);
                $actualizados++;
            }
        }

        if (!empty($errors)) {
            flash('errors', $errors);
        } elseif ($actualizados > 0) {
            flash('success', "Configuración actualizada ($actualizados parámetro" . ($actualizados > 1 ? 's' : '') . ")");
        } else {
            flash('success', 'No hubo cambios para guardar');
        }

        redirect('index.php?page=admin/configuracion');
    }
}
